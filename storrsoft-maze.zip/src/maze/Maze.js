class Maze {
    constructor(rows, cols, cells, startCell, endCell) {
        this.rows = rows;
        this.cols = cols;
        this.cells = cells;
        this.startCell = startCell;
        this.endCell = endCell;
    }
}

export default Maze;